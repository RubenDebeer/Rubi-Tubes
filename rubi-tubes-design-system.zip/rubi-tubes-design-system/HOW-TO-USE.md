# Using the Rubi Tubes Design System in code

1. Copy `tokens.css` and `components/bundle.css` into your site (e.g. `src/styles/`).
2. Import them once, tokens first:
   ```js
   import './styles/tokens.css';
   import './styles/bundle.css';
   ```
3. Use the classes: `rt-btn rt-btn--primary`, `rt-card rt-card--purple`, `rt-tag rt-tag--opinion`,
   `rt-bubble`, `rt-marquee`, `rt-row`, `rt-dots` (dotted page background).
   Type styles are classes too: `display-xl`, `heading-1`, `body`, `eyebrow` …
4. Dark mode: set `<html data-theme="dark">`.

Each `components/<Name>/preview.html` shows the markup; `README.md` next to it has the rules.
Fonts load from Google Fonts via the @import at the top of bundle.css.
