# Button

A chunky outlined button with a hard offset shadow that lifts on hover and pushes in on press.

- Classes: `rt-btn` plus one of `rt-btn--primary` (purple, one per view), `rt-btn--secondary` (surface), `rt-btn--ink` (contact actions) or `rt-btn--pink` (playful one-offs like "Pull the lever").
- Use a real `<a href>` for navigation and `<button type="button">` for actions.
- Labels are plain verbs: "Read my opinions", "Email me". Save the jokes for the copy around the button.
- Add a trailing `<span class="rt-arrow">→</span>` when the button goes somewhere; it nudges right on hover.
- Minimum height 44px. Focus shows a 3px sky outline.
