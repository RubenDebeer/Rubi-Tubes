# SpeechBubble

The stick man's voice: a mono-text bubble with an ink outline that pops in whenever its line changes.

- Class: `rt-bubble`. To replay the pop animation, re-render the bubble with a new key when the text changes.
- Keep lines under about 40 characters: "Oh Hi.", "Stop poking me.", "It was DNS. It is always DNS."
- Place it above and to the side of the mascot, never over body copy.
