# Card

A tinted, slightly tilted card that straightens and jumps up when you hover over it.

- Classes: `rt-card` plus `rt-card--purple` (Opinions), `rt-card--pink` (Notes) or `rt-card--sky` (Contact). Each comes with its own tilt, so a row of three reads as hand-placed.
- Parts: an optional 48px line icon, `rt-card__kicker`, `rt-card__title`, `rt-card__body`, `rt-card__cta` with an `rt-arrow`.
- The whole card is one `<a href>`; don't nest other links inside it.
- Lay cards out in a grid with `repeat(auto-fit, minmax(280px, 1fr))` and a `space-8` gap, so there's room for the shadows and tilt.
