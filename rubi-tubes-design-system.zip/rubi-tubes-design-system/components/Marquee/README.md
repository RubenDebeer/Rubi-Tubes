# Marquee

A tilted purple band with a looping list of interests, separated by ✦.

- Structure: `.rt-marquee > .rt-marquee__track > span + span`. Both spans hold the same text, so the loop at -50% is seamless.
- Mark it `aria-hidden="true"`: it's decoration, and the same topics should appear as real text elsewhere.
- One per page, usually right under the hero. Let it run past both edges of the page (negative side margins).
