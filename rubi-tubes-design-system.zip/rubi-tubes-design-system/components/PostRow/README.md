# PostRow

One line in the "Recently" list: a type tag, the title, the date and an arrow. Hovering slides the row in and tips the arrow.

- Class: `rt-row`, with parts `rt-tag`, `rt-row__title`, `rt-row__date` and `rt-arrow`.
- Stack rows inside a container with a `border-top` in `line`; each row draws its own bottom rule.
- The whole row is one `<a href>` to the post. Dates use the short form "Jun 2026".
