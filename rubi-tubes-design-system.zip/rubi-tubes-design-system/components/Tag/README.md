# Tag

A small outlined pill in mono caps that labels a post's type, or a tilted sky sticker used as a section eyebrow.

- `rt-tag rt-tag--opinion` (purple tint), `rt-tag--cheatsheet` (pink tint), `rt-tag--longread` (sky tint). The colour always matches the content type.
- `rt-tag rt-tag--eyebrow`: the tilted sky pill above a hero heading. Use one per page.
- Tags are labels, not buttons. If one needs to filter, make it a `<button>` and keep the 44px hit area.
