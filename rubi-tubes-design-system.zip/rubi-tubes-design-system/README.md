# Rubi Tubes Design System

The look of ruben.dev — notes & opinions from a software engineer who breaks things, fixes them, and writes some of it down. Off-white dotted paper, ink outlines, hard shadows, loud pastel accents, and things that wobble. It should feel like a whiteboard doodle that learned CSS.

## Principles

1. **Playful, not sloppy.** Elements tilt, bounce and wave — but type, spacing and contrast are strict. The joke lands because the grid is tight.
2. **Ink outlines everything.** Every control, card and tag has a `border-thin` outline in `line` (the ink colour). No grey borders, no soft shadows.
3. **Hard shadows, physical buttons.** Shadows are solid offsets (`shadow-hard-*`). Hover lifts an element (shadow grows), press pushes it in (shadow shrinks to 1px).
4. **One accent leads.** `purple` is the brand. `pink`, `sky` and `sun` are supporting cast — one of them per block, never all at once.
5. **Self-deprecating voice.** Copy is short, honest and a little cheeky.

## Voice and content

- Talk like a person at a braai, not a LinkedIn post: "Say howzit", "Have a look at my notes, or don't. I'm not your boss..."
- Undercut yourself before anyone else can: "Some of my opinions seem good, some are trash."
- Jokes go in asides, stickers and microcopy (`mono-sm`), never in navigation or button labels — those stay plain: "Browse notes", "Email me".
- South African English and spelling (colour, organise). Dates as "Jun 2026".
- Eyebrows are uppercase mono with wide tracking: `NOTES & OPINIONS`, `WHAT YOU'LL FIND HERE`.

## Visual foundations

### Colour

| Role | Token | Use |
| --- | --- | --- |
| Ground | `paper` | Page background with a dot grid: 1.2px dots of ink at 8% alpha, 22px pitch (class `rt-dots`) |
| Text | `ink`, `ink-2`, `ink-3` | Headings, body, muted |
| Brand | `purple` + `on-accent` | Primary buttons, logo, marquee |
| Support | `pink`, `sky`, `sun` | Squiggles, pills, highlights — ink text only |
| Tints | `tint-purple` / `tint-pink` / `tint-sky` | Card fills, paired with `text-purple` / `text-pink` / `text-sky` eyebrows |
| Dark block | `terminal` + `shadow-accent` | Feature blocks that need to punch |

Content types own a colour: **Opinion = purple, Note · Cheat sheet = pink, Note · Long read = sky, Contact = sky/sun.**

`purple-bright` (#b841fb) is the original site purple. It fails contrast with white text, so keep it for doodles and large shapes only.

### Type

- **Display:** Inter Tight 800, tight tracking (`display-xl`, `heading-1…3`).
- **Body:** Inter 400/700 (`body-lg`, `body`, `label`).
- **Mono:** JetBrains Mono for eyebrows, tags, speech bubbles, terminal output and asides.
- All three load from Google Fonts: `https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Inter+Tight:wght@500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap`

### Shape and space

- Radii: buttons `radius-md`, cards `radius-lg`, feature blocks `radius-xl`, tags `radius-pill`.
- Cards: `space-7` padding, `space-8` gaps, alternate `tilt-left` / `tilt-right` / `tilt-slight` in a row.
- Page container max 1200px with a `space-6` gutter; sections open with `space-20`.
- Touch targets are at least 44px tall.

### Motion

Motion is part of the brand — but it's always optional.

| Name | What | Timing |
| --- | --- | --- |
| Lift | Hover: `translate(-2px,-2px)`, shadow sm → 6px | 150ms ease |
| Press | Active: `translate(3px,3px)`, shadow → 1px | 150ms ease |
| Straighten | Card hover: rotate to 0, rise 8px, shadow → lg | 250ms `cubic-bezier(.3,1.5,.5,1)` (overshoot) |
| Pop | New content: scale .6 → 1 with a small rotate | 350ms `cubic-bezier(.3,1.7,.5,1)` |
| Draw | Squiggle underline: stroke-dashoffset to 0 | 1.4s, 0.4s delay |
| Wave / Bob / Blink | Stick man idle loop | 1.6s / 3s / 4s infinite |
| Marquee | Interest ticker | 26s linear infinite |

Always wrap loops in `@media (prefers-reduced-motion: reduce)` → no animation.

## Iconography and illustration

- Icons are inline SVG line drawings: 2–2.5px ink stroke, round caps, `surface` (white) fill. No icon fonts, no emoji.
- The mascot is a hand-drawn stick figure (5px round-cap ink strokes) with a speech bubble. It waves, bobs and blinks; clicking it cycles its lines.
- Doodles: `{ }` in mono purple, a pink `404` sticker, a sky star, a sun-yellow light bulb. Scatter one to three around a hero, floating gently.
- The `✦` glyph separates marquee items.

## Components

Styles live in `components/bundle.css` with an `rt-` prefix: **Button**, **Card**, **Tag**, **SpeechBubble**, **Marquee** and **PostRow**. Each component's guidelines and live preview are in its own folder.
